package com.muping.payroll.query;

public class RoleQueryObject extends QueryObject{
}
