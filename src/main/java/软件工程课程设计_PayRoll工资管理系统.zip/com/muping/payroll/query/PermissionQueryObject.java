package com.muping.payroll.query;

/**
 * 权限查询相关
 */
public class PermissionQueryObject extends QueryObject {

}
