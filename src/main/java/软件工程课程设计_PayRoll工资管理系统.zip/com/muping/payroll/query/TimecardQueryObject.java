package com.muping.payroll.query;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TimecardQueryObject extends QueryObject{
    private Long employeeId=-1L;
}
