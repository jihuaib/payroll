package com.muping.payroll.controller;

/**
 * 所有controller的父类
 */
public abstract class BaseController {
}
